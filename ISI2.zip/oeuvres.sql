-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 23, 2017 at 09:01 PM
-- Server version: 5.5.54-MariaDB-1ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `oeuvres`
--

DELIMITER $$
--
-- Functions
--
CREATE DEFINER=`oeuvres`@`localhost` FUNCTION `generer_pk`(`nom_cle` CHAR(15)) RETURNS int(11)
BEGIN
   declare valeur int;
   select val_cle into valeur from cles
   where id_cle = nom_cle for update;
    set valeur := valeur + 1;
   update cles set val_cle = valeur where id_cle = nom_cle;
   return(valeur);
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `adherent`
--

CREATE TABLE IF NOT EXISTS `adherent` (
  `id_adherent` int(11) NOT NULL,
  `nom_adherent` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prenom_adherent` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_adherent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `adherent`
--

INSERT INTO `adherent` (`id_adherent`, `nom_adherent`, `prenom_adherent`) VALUES
(1, 'Hugo', 'Victor'),
(2, 'Claudel', 'Camille'),
(3, 'Matisse', 'Henri'),
(4, 'Sand', 'Georges'),
(5, 'Balzac', 'Honoré');

-- --------------------------------------------------------

--
-- Table structure for table `cles`
--

CREATE TABLE IF NOT EXISTS `cles` (
  `id_cle` char(15) COLLATE latin1_general_ci NOT NULL,
  `val_cle` int(11) DEFAULT NULL,
  `lib_cle` varchar(80) COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`id_cle`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `cles`
--

INSERT INTO `cles` (`id_cle`, `val_cle`, `lib_cle`) VALUES
('OEUVRE', 7, 'Dernier id Oeuvre'),
('PROPRIETAIRE', 6, 'Dernier id Propriétaire');

-- --------------------------------------------------------

--
-- Table structure for table `oeuvre`
--

CREATE TABLE IF NOT EXISTS `oeuvre` (
  `id_oeuvre` int(11) NOT NULL,
  `id_proprietaire` int(11) NOT NULL,
  `titre` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prix` decimal(11,2) DEFAULT NULL,
  PRIMARY KEY (`id_oeuvre`),
  KEY `FK_OEUVRE_PROPRIETAIRE` (`id_proprietaire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `oeuvre`
--

INSERT INTO `oeuvre` (`id_oeuvre`, `id_proprietaire`, `titre`, `prix`) VALUES
(1, 2, 'Le chapeau à plumes', 557.00),
(2, 3, 'La balançoires', 800.00),
(3, 4, 'Les oreilles du lapin', 350.00),
(4, 2, 'Le penseur debout', 1250.00),
(5, 3, 'Les buveurs de café', 450.00),
(6, 5, 'La petite liseuse', 500.00),
(11, 1, 'sdf', 45.00);

--
-- Triggers `oeuvre`
--
DROP TRIGGER IF EXISTS `tbi_oeuvre`;
DELIMITER //
CREATE TRIGGER `tbi_oeuvre` BEFORE INSERT ON `oeuvre`
 FOR EACH ROW begin
	declare ck_oeuvre_prix condition for sqlstate '45000';
	if (new.prix <= 0) then
		signal ck_oeuvre_prix set message_text = 'ck_oeuvre_prix : prix négatif.';
	end if;
end
//
DELIMITER ;
DROP TRIGGER IF EXISTS `tbu_oeuvre`;
DELIMITER //
CREATE TRIGGER `tbu_oeuvre` BEFORE UPDATE ON `oeuvre`
 FOR EACH ROW begin
	declare ck_oeuvre_prix condition for sqlstate '45000';
	if (new.prix <= 0) then
		signal ck_oeuvre_prix set message_text = 'ck_oeuvre_prix : prix négatif.';
	end if;
end
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `proprietaire`
--

CREATE TABLE IF NOT EXISTS `proprietaire` (
  `id_proprietaire` int(11) NOT NULL,
  `nom_proprietaire` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prenom_proprietaire` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `login` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pwd` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_proprietaire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `proprietaire`
--

INSERT INTO `proprietaire` (`id_proprietaire`, `nom_proprietaire`, `prenom_proprietaire`, `login`, `pwd`) VALUES
(1, 'Gator', 'Ali', 'gator', 'ali'),
(2, 'Zhette', 'Annie', 'zhette', 'annie'),
(3, 'Auchon', 'Paul', 'auchon', 'paul'),
(4, 'Thimaitre', 'Vincent', 'thimaitre', 'vincent'),
(5, 'Iffique', 'Eléonore', 'iffique', 'eléonore');

-- --------------------------------------------------------

--
-- Table structure for table `reservation`
--

CREATE TABLE IF NOT EXISTS `reservation` (
  `date_reservation` datetime NOT NULL,
  `id_oeuvre` int(11) NOT NULL,
  `id_adherent` int(11) NOT NULL,
  `statut` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`date_reservation`,`id_oeuvre`),
  KEY `FK_RESERVATION_ADHERENT` (`id_adherent`),
  KEY `FK_RESERVATION_OEUVRE` (`id_oeuvre`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `reservation`
--

INSERT INTO `reservation` (`date_reservation`, `id_oeuvre`, `id_adherent`, `statut`) VALUES
('2017-03-28 00:00:00', 2, 2, 'Confirmée');

--
-- Triggers `reservation`
--
DROP TRIGGER IF EXISTS `tbi_reservation`;
DELIMITER //
CREATE TRIGGER `tbi_reservation` BEFORE INSERT ON `reservation`
 FOR EACH ROW begin
	declare ck_reservation_statut condition for sqlstate '45000';
	if (new.statut not in ('Attente','Confirmée')) then
		signal ck_reservation_statut set message_text = 'ck_reservation_statut : la colonne statut doit contenir Attente ou Confirmée.';
	end if;
end
//
DELIMITER ;
DROP TRIGGER IF EXISTS `tbu_reservation`;
DELIMITER //
CREATE TRIGGER `tbu_reservation` BEFORE UPDATE ON `reservation`
 FOR EACH ROW begin
	declare ck_reservation_statut condition for sqlstate '45000';
	if (new.statut not in ('Attente','Confirmée')) then
		signal ck_reservation_statut set message_text = 'ck_reservation_statut : la colonne statut doit contenir Attente ou Confirmée.';
	end if;
end
//
DELIMITER ;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `oeuvre`
--
ALTER TABLE `oeuvre`
  ADD CONSTRAINT `FK_OEUVRE_PROPRIETAIRE` FOREIGN KEY (`id_proprietaire`) REFERENCES `proprietaire` (`id_proprietaire`);

--
-- Constraints for table `reservation`
--
ALTER TABLE `reservation`
  ADD CONSTRAINT `FK_RESERVATION_ADHERENT` FOREIGN KEY (`id_adherent`) REFERENCES `adherent` (`id_adherent`),
  ADD CONSTRAINT `FK_RESERVATION_OEUVRE` FOREIGN KEY (`id_oeuvre`) REFERENCES `oeuvre` (`id_oeuvre`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
