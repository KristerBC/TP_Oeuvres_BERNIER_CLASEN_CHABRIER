<footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
        ISI 2 - Professeur : Alain Arsanne 
    </div>
    <!-- Default to the left -->
    2017 -- Projet réalisé par : <strong> BERNIER Maxence - CLASEN Kristoffer - CHABRIER Valentin.</strong> 
</footer>
