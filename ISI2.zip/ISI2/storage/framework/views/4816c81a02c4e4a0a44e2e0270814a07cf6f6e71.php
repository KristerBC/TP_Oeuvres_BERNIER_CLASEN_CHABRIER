<?php $__env->startSection('content'); ?>
<?php echo Form::open(['url' => 'addOeuvre']); ?>

<div class="col-md-12 well well-sm">
    <center><h1><?php echo e(isset($titreVue) ? $titreVue : ''); ?></h1></center>
    <div class="form-horizontal">
        <div class="form-group">

            <label class="col-md-3 control-label">Titre : </label>
            <div class="col-md-3">
                <input type="text" name="titre"
                    placeholder="..." value="" class="form-control" required autofocus>
            </div>
        </div>
        <div class="form-group">
            <label class="col-md-3 control-label">Proprietaire : </label>
            <div class="col-md-3">
                <select class='form-control' name='cbProprietaire' required>
                    <option VALUE=0>Sélectionner un proprietaire</option>
                    <?php foreach(DB::table('proprietaire')->select('*')->get() as $proprietaire): ?>
                      <option value="<?php echo e($proprietaire->id_proprietaire); ?>"><?php echo e($proprietaire->nom_proprietaire); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <div class="form-group">
            <label class="col-md-3 control-label">Prix : </label>
            <div class="col-md-3">
                <input type="text" name="prix" value="" placeholder="..." class="form-control"  required>
            </div>
        </div>
        <div class="form-group">
            <div class="col-md-6 col-md-offset-3">
                <button type="submit" class="btn btn-default btn-primary">
                    <span class="glyphicon glyphicon-ok"></span> Valider
                </button>
                &nbsp;
                <button type="button" class="btn btn-default btn-primary"
                    onclick="javascript: window.location = 'oeuvres';">
                    <span class="glyphicon glyphicon-remove"></span> Annuler
                </button>
            </div>
        </div>
        <div class="col-md-6 col-md-offset-3">
             <?php echo $__env->make('success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
</div>
<?php echo Form::close(); ?>

 <?php $__env->stopSection(); ?>

 <?php $__env->startPush('scripts'); ?>
 <script>
  changePage('menuButton_formOeuvre');
  </script>
  <?php $__env->stopPush(); ?>

<?php echo $__env->make('admin_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>