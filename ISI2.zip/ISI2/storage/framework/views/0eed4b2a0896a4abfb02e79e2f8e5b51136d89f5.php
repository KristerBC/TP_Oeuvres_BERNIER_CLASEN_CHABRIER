<?php $__env->startSection('content'); ?>
<!-- modal-deleteReservation -->
<div class="modal" id="modalDeleteReservation" role="dialog">
  <div class="modal-dialog" >

    <div class="modal-content">

      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title">Supprimer la réservation ?</h4>
      </div>

      <span class="replaceWithBody"></span>

      <div class="modal-footer">
        <button type="button" class="btn btn-default " data-dismiss="modal">Annuler</button>
        <button  id="deleteBtn" type="button" class="btn btn-danger pull-left" data-id="" onclick="deleteReservation()">Supprimer</button>
      </div>

    </div>

      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
  <!-- /.modal -->
<div class="container">
    <div class="blanc">
      <?php echo $__env->make('success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <h1>Liste des réservations</h1>
    </div>
    <div class="box box-primary">
      <div class="box-header"><h3 class="box-title">Liste des oeuvres</h3></div>
      <div class="box-body">
        <div class="table-responsive">
          <table class="table table-bordered table-striped" id="tableReservations">
              <thead>
                  <tr>
                    <th>Titre</th>
                    <th>Date</th>
                    <th>Statut</th>
                    <th>Prénom adhérent</th>
                    <th>Nom adhérent</th>
                    <th>Confirmer</th>
                    <th>Supprimer</th>
                  </tr>
              </thead>

          </table>
        </div>
      </div>
    </div>

    <div class="col-md-6 col-md-offset-3">

    </div>
</div>


<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
  <script>
  var saved_oeuvreId;
  var data = <?php echo json_encode(DB::table('reservation')
    ->join('adherent', 'reservation.id_adherent', '=', 'adherent.id_adherent')
    ->join("oeuvre", "oeuvre.id_oeuvre", "=", "reservation.id_oeuvre")->select('*')->get()); ?>;
  var arr = new Array();
  for(elm in data)
  {
    var res = data[elm].date_reservation.split("-");
    var statut = "";
    if(data[elm].statut != "Confirmée")
    {
      statut = '<a href="confirmReservation?id_oeuvre='+data[elm].id_oeuvre+'&date_reservation='+data[elm].date_reservation+'"><span class="glyphicon glyphicon-thumbs-up" data-toggle="tooltip" data-placement="top" title="Confirmer"></span></a>';
    }
    arr.push(new Array(
      data[elm].titre,
      res[2].substr(0,2)+"/"+res[1]+"/"+res[0],
      data[elm].statut,
      data[elm].prenom_adherent,
      data[elm].nom_adherent,
      statut,
      '<a class="glyphicon glyphicon-trash" data-toggle="modal" data-placement="top" title="Supprimer" href="#" data-toggle="modal" data-target="#modalDeleteReservation" data-placement="top" onclick="setSavedReservationId(' + data[elm].id_oeuvre + ', \''+data[elm].date_reservation+'\')"></a>'
    ));
  };

  $('#tableReservations').DataTable({
    data: arr
  });
  var saved_oeuvreId;
  var saved_dateReservation;
  function setSavedReservationId(id,date){saved_oeuvreId = id;saved_dateReservation=date;}
  function deleteReservation()
  {
    window.location = "deleteReservation?id_oeuvre=" + saved_oeuvreId+"&date_reservation="+saved_dateReservation;
  }
  changePage('menuButton_reservations');
  </script>
  <?php $__env->stopPush(); ?>

<?php echo $__env->make('admin_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>