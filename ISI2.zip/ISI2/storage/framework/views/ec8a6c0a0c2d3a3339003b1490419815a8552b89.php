<?php $__env->startSection('content'); ?>
 /* A compléter */
<div>
    <h1 class="bvn"> Gestion des oeuvres et de leurs réservations </h1>
    <p> Sur ce site, vous trouverez la liste des oeuvres disponibles, pourrez modifier et supprimez-les œuvres. De plus, vous pourrez réserver une oeuvre, ainsi qu'accéder à la liste des œuvres réservée. Vos pourer enfin confirmer et supprimer vos réservations. </p> 
</div>
 /* A compléter */
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>