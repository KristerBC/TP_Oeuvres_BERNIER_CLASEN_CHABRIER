<?php if(isset($erreur) and $erreur != ""): ?>
<p>
    <div class="alert alert-danger alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
        <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> <?php echo e(isset($erreur) ? $erreur : ''); ?>

    </div>
</p>
unset($erreur)
<?php endif; ?>
